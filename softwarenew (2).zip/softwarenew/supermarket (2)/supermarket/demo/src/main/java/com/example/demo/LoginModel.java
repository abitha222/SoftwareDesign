// @Entity
// public class LoginModel {
//         private int id;
//         private String name;
//         private String chocolates;
//         private String fruits;
//         private String diaryproducts;
//         private String grocery;
//         private String vegetables;
//         private String fruits;
//         public int getId() {
//             return id;
//         }
//         public void setId(int id) {
//             this.id = id;
//         }
//         public String getName() {
//             return name;
//         }
//         public void setName(String name) {
//             this.name = name;
//         }
//         public String getChocolates() {
//             return chocolates;
//         }
//         public void setChocolates(String chocolates) {
//             this.chocolates = chocolates;
//         }
//         public String getFruits() {
//             return fruits;
//         }
//         public void setFruits(String fruits) {
//             this.fruits = fruits;
//         }
//         public String getDiaryproducts() {
//             return diaryproducts;
//         }
//         public void setDiaryproducts(String diaryproducts) {
//             this.diaryproducts = diaryproducts;
//         }
//         public String getGrocery() {
//             return grocery;
//         }
//         public void setGrocery(String grocery) {
//             this.grocery = grocery;
//         }
//         public String getVegetables() {
//             return vegetables;
//         }
//         public void setVegetables(String vegetables) {
//             this.vegetables = vegetables;
//         }
//         public String getFruits() {
//             return fruits;
//         }
//         public void setFruits(String fruits) {
//             this.fruits = fruits;
//         }
//         public LoginModel(int id, String name, String chocolates, String fruits, String diaryproducts, String grocery,
//                 String vegetables) {
//             this.id = id;
//             this.name = name;
//             this.chocolates = chocolates;
//             this.fruits = fruits;
//             this.diaryproducts = diaryproducts;
//             this.grocery = grocery;
//             this.vegetables = vegetables;
//         }
    
//         public LoginModel() {
        
//         }

    
// }




