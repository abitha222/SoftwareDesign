// import { createReducer } from '@reduxjs/toolkit';
// import { login, logout } from './userAction';

// const initialState = {
//     user: null,
// };

// const userReducer = createReducer(initialState, (builder) => {
//     builder
//         .addCase(login, (state, action) => {
//             state.user = action.payload;
//         })
//         .addCase(logout, (state) => {
//             state.user = null;
//         });
// });

// export default userReducer;
